./stu 55.0 tests/s1.dat
