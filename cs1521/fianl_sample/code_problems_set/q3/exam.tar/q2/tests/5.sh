./stu 61.1 tests/s2.dat
