./stu 80 tests/s2.dat
