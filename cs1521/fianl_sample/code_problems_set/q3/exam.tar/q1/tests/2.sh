exe tests/s2.s
