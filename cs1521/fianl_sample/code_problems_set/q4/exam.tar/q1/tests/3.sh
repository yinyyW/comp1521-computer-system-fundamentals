exe tests/s3.s
