exe tests/s4.s
