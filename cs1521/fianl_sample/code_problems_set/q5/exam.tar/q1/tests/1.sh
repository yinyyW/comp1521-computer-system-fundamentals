exe tests/a1.s
