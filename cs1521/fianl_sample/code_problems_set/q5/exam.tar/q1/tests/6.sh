exe tests/a6.s
