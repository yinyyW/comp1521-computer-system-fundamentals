exe tests/a7.s
