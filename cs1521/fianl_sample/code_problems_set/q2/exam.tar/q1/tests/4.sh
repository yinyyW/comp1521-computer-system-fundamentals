exe tests/a4.s
