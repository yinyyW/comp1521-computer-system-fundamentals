./stu tests/s1.dat
