./q2 tests/p2.dat
