./q2 tests/p5.dat
