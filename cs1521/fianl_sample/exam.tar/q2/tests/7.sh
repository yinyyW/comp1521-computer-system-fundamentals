./q2 tests/p7.dat
