./q3 4 < tests/jobs1
