./q3 3 < tests/jobs5
