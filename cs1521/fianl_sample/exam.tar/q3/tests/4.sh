./q3 5 < tests/jobs3
